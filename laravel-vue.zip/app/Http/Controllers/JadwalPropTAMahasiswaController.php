<?php

namespace App\Http\Controllers;

use App\Models\JadwalPropTAMahasiswa;
use Illuminate\Http\Request;

class JadwalPropTAMahasiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(JadwalPropTAMahasiswa $jadwalPropTAMahasiswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(JadwalPropTAMahasiswa $jadwalPropTAMahasiswa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, JadwalPropTAMahasiswa $jadwalPropTAMahasiswa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(JadwalPropTAMahasiswa $jadwalPropTAMahasiswa)
    {
        //
    }
}
