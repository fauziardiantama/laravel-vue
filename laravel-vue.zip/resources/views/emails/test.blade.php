{{-- an stylish simple email template --}}
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Test Email - Sadewa</title>
</head>
<body>
    <h1>Test Email</h1>
    <p>{{ $pesan }}</p>
</body>
</html>