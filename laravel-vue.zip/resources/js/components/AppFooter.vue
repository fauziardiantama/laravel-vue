<template>
  <CFooter>
    <div>
      <a href="https://portald3ti.vokasi.uns.ac.id/" target="_blank">KMM-TA</a>
      <span class="ms-1"
        >&copy; {{ new Date().getFullYear() }} D3 Teknik Informatika.</span
      >
    </div>
    <div class="ms-auto">
      <span class="me-1" target="_blank">Powered by</span>
      <a href="https://coreui.io/vue">CoreUI for Vue</a>
    </div>
  </CFooter>
</template>

<script>
export default {
  name: 'AppFooter',
}
</script>
